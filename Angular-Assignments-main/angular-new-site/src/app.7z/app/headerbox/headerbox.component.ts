import { Component } from '@angular/core';

@Component({
  selector: 'app-headerbox',
  templateUrl: './headerbox.component.html',
  styleUrls: ['./headerbox.component.css']
})
export class HeaderboxComponent {

}
