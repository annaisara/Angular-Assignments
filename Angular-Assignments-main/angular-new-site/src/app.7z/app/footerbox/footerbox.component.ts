import { Component } from '@angular/core';

@Component({
  selector: 'app-footerbox',
  templateUrl: './footerbox.component.html',
  styleUrls: ['./footerbox.component.css']
})
export class FooterboxComponent {

}
