import { Component } from '@angular/core';

@Component({
  selector: 'app-gallerybox',
  templateUrl: './gallerybox.component.html',
  styleUrls: ['./gallerybox.component.css']
})
export class GalleryboxComponent {

}
